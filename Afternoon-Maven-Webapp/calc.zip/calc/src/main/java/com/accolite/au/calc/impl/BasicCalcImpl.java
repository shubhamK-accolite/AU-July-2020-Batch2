package com.accolite.au.calc.impl;

import com.accolite.au.calc.interfaces.BasicCalc;

public class BasicCalcImpl implements BasicCalc {

	@Override
	public void add(int x, int y) {
		// TODO Auto-generated method stub
		System.out.println(x + y);
	}

	@Override
	public void sub(int x, int y) {
		// TODO Auto-generated method stub
		System.out.println(x - y);
	}

	@Override
	public void divide(int x, int y) {
		// TODO Auto-generated method stub
		try {	
			System.out.println((double) x / y );
		} catch (ArithmeticException e) {
	         System.out.println ("Can't be divided by Zero"+e);
	      }
	}

	@Override
	public void multiply(int x, int y) {
		// TODO Auto-generated method stub
		System.out.println(x * y);
	}
}

