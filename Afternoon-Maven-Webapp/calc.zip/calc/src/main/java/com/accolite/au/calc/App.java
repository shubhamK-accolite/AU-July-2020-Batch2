package com.accolite.au.calc;

import com.accolite.au.calc.impl.BasicCalcImpl;
import com.accolite.au.calc.interfaces.BasicCalc;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
//        System.out.println( "Hello World!" );
//        BasicCalc basicCalc = new BasicCalcImpl();
//        
//        basicCalc.add(1, 3);
//        basicCalc.divide(113, 4);
//        basicCalc.sub(44, 21);
//        basicCalc.multiply(4,5);
    }
}
