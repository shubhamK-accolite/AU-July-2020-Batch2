package com.accolite.au.calc.interfaces;

public interface BasicCalc {
	void add(int x,int y);
	void sub(int x,int y);
	void divide(int x, int y);
	void multiply(int x,int y);
}

