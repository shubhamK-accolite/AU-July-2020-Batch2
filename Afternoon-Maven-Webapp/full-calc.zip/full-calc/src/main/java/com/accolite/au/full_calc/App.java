package com.accolite.au.full_calc;

import java.util.Scanner;

import com.accolite.au.calc.impl.BasicCalcImpl;
import com.accolite.au.calc.interfaces.BasicCalc;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
      
      System.out.println( "Hello World! This is full Calculator" );
      BasicCalc basicCalc = new BasicCalcImpl();
      Scanner scan = new Scanner(System.in);
      System.out.print("Enter 2 number: (x,y)" );
      int num1 = scan.nextInt();
      int num2 = scan.nextInt();
      // Closing Scanner after the use
      scan.close();
      System.out.print("Sum :" );
      basicCalc.add(1, 3);
      System.out.print("Division : " );
      basicCalc.divide(113, 4);
      System.out.print("Substraction :" );
      basicCalc.sub(44, 21);
      System.out.print("Multiplication :" );
      basicCalc.multiply(4,5);
    }
}
