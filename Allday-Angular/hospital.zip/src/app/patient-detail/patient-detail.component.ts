import { Component, OnInit } from '@angular/core';
import {PatientFileService} from '../patient-file.service';

@Component({
  selector: 'app-patient-detail',
  templateUrl: './patient-detail.component.html',
  styleUrls: ['./patient-detail.component.css']
})
export class PatientDetailComponent implements OnInit {
  messageFromSibling;
  subscription;
  constructor(private patientService: PatientFileService) {
    this.subscription = this.patientService.getMessage()
    .subscribe(mymessage => this.messageFromSibling = mymessage)
  }
   
  ngOnDestroy() {
    this.subscription.unsubscribe();
  }

  ngOnInit(): void {
  }

}
