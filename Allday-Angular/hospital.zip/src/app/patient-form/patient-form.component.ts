import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
 import { Output, EventEmitter } from '@angular/core';
import {PatientFileService} from "../patient-file.service";


@Component({
  selector: 'app-patient-form',
  templateUrl: './patient-form.component.html',
  styleUrls: ['./patient-form.component.css']
})
export class PatientFormComponent implements OnInit {

 
  reportForm = new FormGroup({
    firstName: new FormControl(''),
    lastName: new FormControl(''),
    age: new FormControl(''),
    diagnosis :new FormControl('')
  });
  constructor(private patientService: PatientFileService) { }

   @Output()  
   private onFormGroupChange = new EventEmitter<Array<string>>();

  ngOnInit() {
    
  }
 
  onSubmit() {
    // alert("Form Submitted");
    //console.log(this.patientForm)
     console.warn(this.reportForm.value);
    
     this.patientService.updateMessage(this.reportForm.value);
       this.onFormGroupChange.emit(this.reportForm.value);
    
        
   }

}
