import { Injectable } from '@angular/core';
import { Observable, Subject } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class PatientFileService {

  constructor(){}
private myMessage = new Subject<Array<string>>();

getMessage() : Observable<Array<string>> {
  return this.myMessage.asObservable();
}
updateMessage(message : Array<string>){
  this.myMessage.next(message);
}
}
