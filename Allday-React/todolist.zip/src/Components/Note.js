import React, {Component} from 'react';
import {Greet} from './Greet';
// import Mylist from './Mylist';

class Note extends Component{
    constructor(props ){
        super(props)
        this.state = {
            tasklist :[],
            task : '',
            name : 'Shubham',
            selectedTask:''
        }
    }

    handleTask = (event) => {
      
        console.log("HandleChange Called ",event.target.value);
        this.setState({task:event.target.value})
    }
    // handleEdit = (event) => {
    //     this.setState({address:event.target.value})
    // }
    handleSubmit = (event) => {
         event.preventDefault()
         var array = this.state.tasklist; // make a separate copy of the array
         array.push(this.state.task)
        this.setState(() =>{
            this.setState({tasklist: array})
        })
        this.setState({task:''})
        console.log("HandleSubmit Called ",this.state.tasklist);
    }
    handleDelete = (event) =>{
        console.log("Task Deleted ",this.state.selectedTask);
        var array = this.state.tasklist; // make a separate copy of the array
        var index = this.state.selectedTask[0]
        if (index !== -1) {
          array.splice(index, 1);
          this.setState({tasklist: array})
        }  
    }

    handleEdit = (event) => {
        console.log("Task Edit : ",this.state.selectedTask);
        var array = this.state.tasklist; // make a separate copy of the array
        var index = this.state.selectedTask[0]
        var editval = array[index]
        if (index !== -1) {
          array.splice(index, 1);
          this.setState({tasklist: array})
          this.setState({task:editval})
        }  
    }

    handleClearList = (event) => {
        event.preventDefault()
        this.setState({tasklist:[]})
    }

    render() {
        return <>

            <Greet name = {this.state.name}/>
            <div class="container">
            <form  onSubmit={this.handleSubmit}>
         
                <label>Task : </label>
                <input  placeholder="Enter your task here..." class="form-control" type= "text" value={this.state.task} onChange= {this.handleTask}></input>
                <br/>
                <br/>
               
                <button class=" btn btn-success  btn-lg">Add Task</button>
            </form>
            <br/> <br/>
            <br/> <br/>
        <div>
        <div class="form-group">
            
        <select  class="form-control" value={this.state.selectedTask}
              onChange={(e) => this.setState({selectedTask: e.target.value})}>>
     { this.state.tasklist.map((task,index) => <option>{index} : {task}</option>)}
        </select>
    
        <button class=" btn btn-primary btn-sm" value={this.state.selectedTask} onClick= {this.handleEdit} >Edit</button>
        <button class=" btn btn-warning btn-sm" value={this.state.selectedTask} onClick= {this.handleDelete}>Delete</button>
        </div>
        </div>
        <br/> 
        <button class="btn btn-danger btn-lg" value ={this.state.tasklist} onClick = {this.handleClearList}> Clear List </button>
        </div>
        </>
    }
}

export default Note 