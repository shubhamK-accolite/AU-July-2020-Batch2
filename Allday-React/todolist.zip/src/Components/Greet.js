import React from 'react';

export const Greet = (props) => {
    console.log(props);
return <h1> Hello {props.name}!</h1>;
}

// // Default component 
// const Greet = () => <h1> Hello World</h1>
// export default Greet

// named component imported as CompName
// default component imported as {Compname}