import React from 'react';

import './App.css';
import Note from  './Components/Note'

function App() {
  return (
    <div className="App">  
    <h1>TODO APP</h1>
    <Note/>
    </div>
  );
}

export default App;
